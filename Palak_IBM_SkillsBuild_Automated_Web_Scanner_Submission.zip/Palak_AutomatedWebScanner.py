#!/usr/bin/env python3
"""
Automated Web Security Scanner (Beginner Project)
Checks basic HTTP security headers and simple CORS response behavior.

IMPORTANT:
- Scan only websites you own or have explicit permission to test.
- This is a basic educational checker, not a full penetration-testing tool.
- It does not exploit vulnerabilities or attempt authentication bypass.
"""

import argparse
import json
import sys
from datetime import datetime, timezone
from urllib.parse import urlparse

import requests


SECURITY_HEADERS = {
    "Strict-Transport-Security": {
        "description": "Encourages browsers to use HTTPS for future requests.",
        "https_only": True,
    },
    "Content-Security-Policy": {
        "description": "Helps restrict the sources from which page resources can load.",
        "https_only": False,
    },
    "X-Content-Type-Options": {
        "description": "Helps prevent MIME-type sniffing.",
        "https_only": False,
    },
    "X-Frame-Options": {
        "description": "Helps reduce clickjacking risk in browsers that honor this header.",
        "https_only": False,
    },
    "Referrer-Policy": {
        "description": "Controls how much referrer information browsers send.",
        "https_only": False,
    },
    "Permissions-Policy": {
        "description": "Allows a site to limit use of certain browser features.",
        "https_only": False,
    },
}


def validate_url(url):
    """Return a normalized URL or raise ValueError for invalid input."""
    url = url.strip()
    if not url:
        raise ValueError("URL cannot be empty.")
    if "://" not in url:
        url = "https://" + url

    parsed = urlparse(url)
    if parsed.scheme not in ("http", "https"):
        raise ValueError("Only http:// and https:// URLs are supported.")
    if not parsed.hostname:
        raise ValueError("Please provide a valid hostname, for example https://example.com.")
    if parsed.username or parsed.password:
        raise ValueError("Do not include usernames or passwords in the URL.")
    return url


def assess_cors(headers):
    """
    Perform a passive, simple CORS header review from the response.
    This does not send an Origin probe and cannot prove exploitability.
    """
    allow_origin = headers.get("Access-Control-Allow-Origin")
    allow_credentials = headers.get("Access-Control-Allow-Credentials", "").lower()

    if not allow_origin:
        return {
            "status": "INFO",
            "finding": "No Access-Control-Allow-Origin header in this response.",
            "details": "This may be appropriate. CORS is only needed when browser code on another origin must access this resource.",
        }

    if allow_origin.strip() == "*" and allow_credentials == "true":
        return {
            "status": "REVIEW",
            "finding": "Wildcard origin and credentials=true are both present.",
            "details": "Browsers normally reject credentialed CORS responses using a wildcard origin. Review the server's complete CORS configuration.",
        }

    if allow_origin.strip() == "*":
        return {
            "status": "REVIEW",
            "finding": "Wildcard Access-Control-Allow-Origin is present.",
            "details": "A wildcard can be appropriate for public, non-sensitive resources. Confirm that sensitive data is not exposed and review other CORS headers.",
        }

    if allow_credentials == "true":
        return {
            "status": "INFO",
            "finding": "A specific allowed origin and credentials=true are present.",
            "details": "This is not automatically a vulnerability. Confirm the allowed origin is strictly validated and appropriate for the resource.",
        }

    return {
        "status": "INFO",
        "finding": f"Access-Control-Allow-Origin is set to {allow_origin!r}.",
        "details": "Review whether this origin is intentionally trusted. This passive check does not validate server-side origin handling.",
    }


def scan_url(url, timeout=10):
    """Fetch one URL and assess its response headers."""
    url = validate_url(url)
    response = requests.get(
        url,
        timeout=timeout,
        allow_redirects=True,
        headers={"User-Agent": "Beginner-Web-Security-Scanner/1.0"},
    )

    final_url = response.url
    final_scheme = urlparse(final_url).scheme
    headers = response.headers

    findings = []
    for header, info in SECURITY_HEADERS.items():
        value = headers.get(header)
        if value:
            findings.append({
                "header": header,
                "status": "PRESENT",
                "value": value,
                "description": info["description"],
            })
        elif info["https_only"] and final_scheme != "https":
            findings.append({
                "header": header,
                "status": "NOT_CHECKED",
                "value": None,
                "description": "Normally relevant only when the site is accessed over HTTPS.",
            })
        else:
            findings.append({
                "header": header,
                "status": "MISSING",
                "value": None,
                "description": info["description"],
            })

    cors = assess_cors(headers)
    return {
        "scanner": "Automated Web Security Scanner",
        "scan_time_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "requested_url": url,
        "final_url": final_url,
        "http_status": response.status_code,
        "https_after_redirect": final_scheme == "https",
        "security_headers": findings,
        "cors_review": cors,
        "limitations": [
            "Only the final HTTP response headers are inspected.",
            "A missing header is a review item, not proof of an exploitable vulnerability.",
            "CORS is assessed passively; no Origin probe or exploit test is performed.",
            "The tool does not crawl pages, test authentication, or scan for SQL injection/XSS.",
        ],
    }


def print_report(report):
    """Print a readable report to the terminal."""
    print("\n" + "=" * 68)
    print("AUTOMATED WEB SECURITY SCANNER — RESULTS")
    print("=" * 68)
    print(f"Requested URL : {report['requested_url']}")
    print(f"Final URL     : {report['final_url']}")
    print(f"HTTP status   : {report['http_status']}")
    print(f"HTTPS final   : {'Yes' if report['https_after_redirect'] else 'No'}")
    print(f"Scan time UTC : {report['scan_time_utc']}")
    print("\nSECURITY HEADERS")
    print("-" * 68)
    for item in report["security_headers"]:
        print(f"[{item['status']}] {item['header']}")
        if item["value"]:
            print(f"    Value: {item['value']}")
        print(f"    Note : {item['description']}")
    print("\nCORS REVIEW")
    print("-" * 68)
    cors = report["cors_review"]
    print(f"[{cors['status']}] {cors['finding']}")
    print(f"    {cors['details']}")
    print("\nLIMITATIONS")
    for limitation in report["limitations"]:
        print(f"- {limitation}")
    print("=" * 68)


def main():
    parser = argparse.ArgumentParser(
        description="Check basic HTTP security headers and passively review CORS."
    )
    parser.add_argument("url", help="Target URL, e.g. https://example.com")
    parser.add_argument("--timeout", type=int, default=10, help="Request timeout in seconds (default: 10)")
    parser.add_argument("--json", dest="json_path", help="Optional path to save machine-readable JSON results")
    args = parser.parse_args()

    if args.timeout < 1 or args.timeout > 60:
        parser.error("--timeout must be between 1 and 60 seconds")

    try:
        report = scan_url(args.url, timeout=args.timeout)
    except ValueError as exc:
        print(f"Input error: {exc}", file=sys.stderr)
        return 2
    except requests.exceptions.SSLError:
        print("Connection failed: TLS/SSL certificate verification failed. Check the URL/certificate; do not disable verification.", file=sys.stderr)
        return 1
    except requests.exceptions.Timeout:
        print("Connection failed: request timed out. Try again or increase --timeout.", file=sys.stderr)
        return 1
    except requests.exceptions.RequestException as exc:
        print(f"Connection failed: {exc}", file=sys.stderr)
        return 1

    print_report(report)

    if args.json_path:
        try:
            with open(args.json_path, "w", encoding="utf-8") as file:
                json.dump(report, file, indent=2, ensure_ascii=False)
            print(f"\nJSON report saved to: {args.json_path}")
        except OSError as exc:
            print(f"Could not save JSON report: {exc}", file=sys.stderr)
            return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

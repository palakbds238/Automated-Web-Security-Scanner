# Automated Web Security Scanner

**Project:** Automated Web Security Scanner  
**Program:** IBM SkillsBuild Cyber Security BootCamp 2026 | BharatCares  
**Author:** Palak Bordiya  
**Level:** Beginner  
**Language:** Python 3

## 1. Project overview

This command-line Python project performs a basic, passive review of a website's final HTTP response. It checks for six commonly used HTTP security headers and reviews the returned CORS headers for configurations that may deserve further review.

The scanner is intended for learning and defensive security awareness. A missing header or unusual CORS value is a review item, not proof that a website is vulnerable.

## 2. Features

- Checks `Strict-Transport-Security` (when the final URL uses HTTPS)
- Checks `Content-Security-Policy`
- Checks `X-Content-Type-Options`
- Checks `X-Frame-Options`
- Checks `Referrer-Policy`
- Checks `Permissions-Policy`
- Passively reviews `Access-Control-Allow-Origin` and `Access-Control-Allow-Credentials`
- Follows HTTP redirects and displays the final URL and status code
- Handles common connection, timeout, TLS and input errors
- Can save a JSON report for later review

## 3. Technologies

- Python 3
- `requests` for HTTP requests
- Python standard library: `argparse`, `json`, `sys`, `datetime`, and `urllib.parse`

## 4. Requirements

- Python 3.9 or newer (Python 3.10+ recommended)
- Internet access for a remote authorized target, or access to a local test server
- `pip` to install the dependency

## 5. Setup and run instructions

### Windows (PowerShell)

1. Put `Palak_AutomatedWebScanner.py` and `requirements.txt` in the same folder.
2. Open PowerShell in that folder.
3. (Optional but recommended) Create a virtual environment:

   ```powershell
   py -m venv .venv
   .\.venv\Scripts\Activate.ps1
   ```

   If PowerShell blocks activation, you can use `.venv\Scripts\python.exe` directly instead.

4. Install the dependency:

   ```powershell
   py -m pip install -r requirements.txt
   ```

5. Run the scanner against a website you own or are authorized to test:

   ```powershell
   py Palak_AutomatedWebScanner.py https://example.com
   ```

6. Save a JSON report (optional):

   ```powershell
   py Palak_AutomatedWebScanner.py https://example.com --json scan_report.json
   ```

7. Use a longer timeout if needed:

   ```powershell
   py Palak_AutomatedWebScanner.py https://example.com --timeout 20
   ```

### macOS / Linux

```bash
python3 -m venv .venv
source .venv/bin/activate
python3 -m pip install -r requirements.txt
python3 Palak_AutomatedWebScanner.py https://example.com
```

## 6. Dataset / target information

This is a rule-based HTTP-header checker, so it does not require a machine-learning dataset. For a demonstration, use a local test server or a public website only when you are permitted to test it. `https://example.com` can be used for a basic connectivity demonstration, but it is not a comprehensive security benchmark.

## 7. Example output

Output varies depending on the target's current response headers.

```text
====================================================================
AUTOMATED WEB SECURITY SCANNER — RESULTS
====================================================================
Requested URL : https://example.com
Final URL     : https://example.com/
HTTP status   : 200
HTTPS final   : Yes
Scan time UTC : <generated at runtime>

SECURITY HEADERS
--------------------------------------------------------------------
[MISSING] Content-Security-Policy
    Note : Helps restrict the sources from which page resources can load.
...
CORS REVIEW
--------------------------------------------------------------------
[INFO] No Access-Control-Allow-Origin header in this response.
...
```

The above is illustrative only; actual headers, status codes and findings may differ.

## 8. Scope and limitations

- Inspects only the final response headers; it does not crawl the website.
- Does not exploit vulnerabilities or test SQL injection, cross-site scripting, authentication, or authorization.
- CORS review is passive. It does not send an `Origin` test request or prove whether a configuration is exploitable.
- A header marked missing may be intentional depending on the application and deployment.
- `Strict-Transport-Security` is relevant to HTTPS; it is not marked missing for a final HTTP URL.
- The scanner does not replace a professional security assessment.

## 9. Responsible-use note

Only scan systems you own or have explicit permission to assess. Do not use the tool to disrupt services, bypass access controls, or collect private data. Keep TLS certificate verification enabled.

## 10. References

- MDN Web Docs — HTTP headers: https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers
- MDN Web Docs — Content Security Policy: https://developer.mozilla.org/en-US/docs/Web/HTTP/CSP
- MDN Web Docs — Cross-Origin Resource Sharing (CORS): https://developer.mozilla.org/en-US/docs/Web/HTTP/CORS
- OWASP Secure Headers Project: https://owasp.org/www-project-secure-headers/

## 11. Submission files

- `Palak_AutomatedWebScanner.py` — source code
- `requirements.txt` — dependency list
- `Palak_ProjectReport.docx` — project documentation
- `README.md` — project overview and run instructions
